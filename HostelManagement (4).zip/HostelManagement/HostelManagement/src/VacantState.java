import HostelManagement.*;
public class VacantState implements RoomState {
    @Override
    public void handle(Room room) {
        room.setState(new OccupiedState());
    }

    @Override
    public String getState() {
        return "vacant";
    }
}