import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import HostelManagement.*;

public class FeedbackMediator implements Mediator {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hostelmanagement";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @Override
    public void sendFeedback(String email, String feedback) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "UPDATE students SET feedback = ? WHERE email = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, feedback);
                pstmt.setString(2, email);
                int rowsUpdated = pstmt.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Feedback updated successfully for email: " + email);
                } else {
                    System.out.println("Failed to update feedback for email: " + email);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
