public interface RoomAvailabilitySubject {
    void registerObserver(RoomAvailabilityObserver observer);
    void removeObserver(RoomAvailabilityObserver observer);
    void notifyObservers(boolean isRoomAvailable);
}