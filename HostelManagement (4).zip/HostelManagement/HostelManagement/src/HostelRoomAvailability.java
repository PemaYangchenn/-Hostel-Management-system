import java.util.ArrayList;
import java.util.List;

public class HostelRoomAvailability implements RoomAvailabilitySubject {
    private List<RoomAvailabilityObserver> observers;
    private boolean isRoomAvailable;

    public HostelRoomAvailability() {
        observers = new ArrayList<>();
        isRoomAvailable = false; // Initially, no rooms available
    }

    public void setRoomAvailable(boolean isAvailable) {
        this.isRoomAvailable = isAvailable;
        notifyObservers(isAvailable);
    }

    @Override
    public void registerObserver(RoomAvailabilityObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(RoomAvailabilityObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(boolean isRoomAvailable) {
        for (RoomAvailabilityObserver observer : observers) {
            observer.update(isRoomAvailable);
        }
    }
}