import HostelManagement.*;
public class OccupiedState implements RoomState {
    @Override
    public void handle(Room room) {
        room.setState(new VacantState());
    }

    @Override
    public String getState() {
        return "occupied";
    }
}
