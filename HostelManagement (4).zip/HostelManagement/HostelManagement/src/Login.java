import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import HostelManagement.*;
// interface LoginObserver {
//     void onLoginSuccess(String userType);
//     void onLoginFailure();
// }

public class Login extends JFrame {

    private final List<LoginObserver> observers = new ArrayList<>();
    private JLabel statusLabel;

    public Login() {
        setTitle("Login Page");
        setSize(300, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Login");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titleLabel);
        panel.add(new JLabel());

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        panel.add(emailLabel);
        panel.add(emailField);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        panel.add(passwordLabel);
        panel.add(passwordField);

        JButton loginButton = new JButton("Login");
        panel.add(loginButton);

        JLabel signupLabel = new JLabel("Don't have an account? Sign up");
        signupLabel.setForeground(Color.BLUE);
        signupLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signupLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
        // Redirect to signup page
        dispose(); // Close the current window
        Signup signupPage = new Signup(null); // Create a new signup page
        signupPage.setVisible(true); // Show the signup page
    }
});
panel.add(signupLabel);

        statusLabel = new JLabel("");
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(statusLabel);

        

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                if (email.isEmpty() || password.isEmpty()) {
                    statusLabel.setText("Please fill in all fields");
                    return;
                }

                AuthenticationManager authManager = AuthenticationManager.getInstance();
                String result = authManager.authenticate(email, password);

                if (result.equals("Student")) {
                    notifyObservers("Student");
                    JOptionPane.showMessageDialog(Login.this, "Login successful as student", "Success", JOptionPane.INFORMATION_MESSAGE);
                    StudentHomePage studentHomePage = new StudentHomePage(email);
                    studentHomePage.setVisible(true);
                    dispose();
                } else if (result.equals("Admin")) {
                    notifyObservers("Admin");
                    JOptionPane.showMessageDialog(Login.this, "Login successful as admin", "Success", JOptionPane.INFORMATION_MESSAGE);
                    AdminHomePage adminHomePage = new AdminHomePage(email);
                    adminHomePage.setVisible(true);
                    dispose();
                } else {
                    statusLabel.setText(result);
                    notifyObservers(null);
                }
            }
        });

        add(panel);
    }

    public void addObserver(LoginObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(LoginObserver observer) {
        observers.remove(observer);
    }

    private void notifyObservers(String userType) {
        for (LoginObserver observer : observers) {
            if (userType != null) {
                observer.onLoginSuccess(userType);
            } else {
                observer.onLoginFailure();
            }
        }
    }

    public static void main(String[] args) {
        Login loginPage = new Login();

        LoginObserver observer = new LoginObserver() {
            @Override
            public void onLoginSuccess(String userType) {
                System.out.println("Login successful as " + userType);
            }

            @Override
            public void onLoginFailure() {
                System.out.println("Login failed");
            }
        };

        loginPage.addObserver(observer);

        SwingUtilities.invokeLater(() -> loginPage.setVisible(true));
    }
}
