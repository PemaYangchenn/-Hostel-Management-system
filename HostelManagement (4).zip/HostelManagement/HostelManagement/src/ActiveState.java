import HostelManagement.*;
public class ActiveState implements StudentState {
    @Override
    public void handleState(StudentContext context) {
        System.out.println("Student is currently active.");
    }
}
