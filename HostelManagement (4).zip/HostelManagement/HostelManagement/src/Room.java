import HostelManagement.*;
public class Room implements HostelComponent {
    private int roomId;
    private String roomNumber;
    private int capacity;
    private RoomState state;

    public Room(int roomId, String roomNumber, int capacity) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.capacity = capacity;
        this.state = new VacantState(); // Initial state
    }

    public void setState(RoomState state) {
        this.state = state;
    }

    public RoomState getState() {
        return state;
    }

    @Override
    public void display(StringBuilder builder, String indent) {
        builder.append(indent)
               .append("Room ID: ").append(roomId)
               .append(", Room Number: ").append(roomNumber)
               .append(", Capacity: ").append(capacity)
               .append(", State: ").append(state.getState())
               .append("\n");
    }
}
