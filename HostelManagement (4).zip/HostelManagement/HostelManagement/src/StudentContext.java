import HostelManagement.*;
public class StudentContext {
    private StudentState state;
    private String enrollmentNumber;

    public StudentContext(String enrollmentNumber) {
        this.enrollmentNumber = enrollmentNumber;
        // Default state is active
        this.state = new ActiveState();
    }

    public void setState(StudentState state) {
        this.state = state;
    }

    public StudentState getState() {
        return state;
    }

    public String getEnrollmentNumber() {
        return enrollmentNumber;
    }

    public void applyState() {
        state.handleState(this);
    }
}
