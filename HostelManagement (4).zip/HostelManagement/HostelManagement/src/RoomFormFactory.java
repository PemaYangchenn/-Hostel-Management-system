import javax.swing.JFrame;
import HostelManagement.*;

public class RoomFormFactory implements FormFactory {
    @Override
    public JFrame createForm() {
        return new AddRoomForm();
    }
}
