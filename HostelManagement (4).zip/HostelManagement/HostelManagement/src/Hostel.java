import java.util.List;
import HostelManagement.*;

public class Hostel implements HostelComponent {
    private int hostelId;
    private String hostelName;
    private List<HostelComponent> rooms;

    public Hostel(int hostelId, String hostelName, List<HostelComponent> rooms) {
        this.hostelId = hostelId;
        this.hostelName = hostelName;
        this.rooms = rooms;
    }

    @Override
    public void display(StringBuilder builder, String indent) {
        builder.append(indent)
               .append("Hostel ID: ").append(hostelId)
               .append(", Hostel Name: ").append(hostelName)
               .append("\n");
        for (HostelComponent room : rooms) {
            room.display(builder, indent + "  ");
        }
    }
}
