import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import HostelManagement.*;

public class AdminHomePage extends JFrame {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/hostelmanagement";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public AdminHomePage(String email) {
        setTitle("Admin Home Page");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        String realName = getRealName(email);

        JLabel welcomeLabel = new JLabel("Welcome back, " + realName + "!");
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(welcomeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 20, 20));
        JButton addHostelButton = new JButton("Add Hostel");
        JButton addRoomButton = new JButton("Add Room");
        JButton yearAllocationButton = new JButton("Allocate by Year");
        JButton viewAllocationsButton = new JButton("View Allocations");
        JButton viewStructureButton = new JButton("View Structure");
        JButton suspendStudentButton = new JButton("Suspend Student");
        JButton viewPaymentButton = new JButton("View Payment");
        JButton viewFeedbackButton = new JButton("View Feedback");
        JButton logoutButton = new JButton("Logout");

        buttonPanel.add(addHostelButton);
        buttonPanel.add(addRoomButton);
        buttonPanel.add(yearAllocationButton);
        buttonPanel.add(viewAllocationsButton);
        buttonPanel.add(viewStructureButton);
        buttonPanel.add(suspendStudentButton);
        buttonPanel.add(viewPaymentButton);
        buttonPanel.add(viewFeedbackButton);
        buttonPanel.add(logoutButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        addHostelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FormFactory hostelFactory = new HostelFormFactory();
                JFrame hostelForm = hostelFactory.createForm();
                hostelForm.setVisible(true);
            }
        });

        viewPaymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewPayments();
            }
        });

        addRoomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FormFactory roomFactory = new RoomFormFactory();
                JFrame roomForm = roomFactory.createForm();
                roomForm.setVisible(true);
            }
        });

        yearAllocationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RoomAllocator allocator = new RoomAllocator();
                allocator.setStrategy(new YearWiseAllocationStrategy());
                allocator.allocate();
                JOptionPane.showMessageDialog(AdminHomePage.this, "Rooms allocated by year successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        viewAllocationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewRoomAllocations();
            }
        });

        viewStructureButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewStructure();
            }
        });

        suspendStudentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enrollmentNumber = JOptionPane.showInputDialog("Enter enrollment number to suspend:");
                if (enrollmentNumber != null && !enrollmentNumber.trim().isEmpty()) {
                    if (isEnrollmentNumberValid(enrollmentNumber)) {
                        suspendStudent(enrollmentNumber);
                    } else {
                        JOptionPane.showMessageDialog(AdminHomePage.this, "Invalid enrollment number!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(AdminHomePage.this, "Enrollment number cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        viewFeedbackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewFeedback();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Login().setVisible(true);
                dispose();
            }
        });

        add(panel);
    }

    private String getRealName(String email) {
        String username = "User"; // Default value
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT username FROM admin WHERE email = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, email);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        username = rs.getString("username");
                    } else {
                        System.out.println("User not found for email: " + email);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return username;
    }

    private void viewFeedback() {
        JFrame feedbackFrame = new JFrame("Student Feedback");
        feedbackFrame.setSize(800, 400);
        feedbackFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    
        String[] columnNames = {"Enrollment Number", "Username", "Year", "Hostel Name", "Room Number", "Feedback"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);
    
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        feedbackFrame.add(scrollPane);
    
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT s.enrollmentNumber, s.username, s.year, h.hostel_name, r.room_number, s.feedback " +
                           "FROM students s " +
                           "JOIN rooms r ON s.room_id = r.room_id " +
                           "JOIN hostels h ON r.hostel_id = h.hostel_id";
            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {
    
                while (rs.next()) {
                    String enrollmentNumber = rs.getString("enrollmentNumber");
                    String username = rs.getString("username");
                    String year = rs.getString("year");
                    String hostelName = rs.getString("hostel_name");
                    String roomNumber = rs.getString("room_number");
                    String feedback = rs.getString("feedback");
    
                    model.addRow(new Object[]{enrollmentNumber, username, year, hostelName, roomNumber, feedback});
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    
        feedbackFrame.setVisible(true);
    }

    private boolean isEnrollmentNumberValid(String enrollmentNumber) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT enrollmentNumber FROM students WHERE enrollmentNumber = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, enrollmentNumber);
                try (ResultSet rs = pstmt.executeQuery()) {
                    return rs.next();
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    private void suspendStudent(String enrollmentNumber) {
        StudentContext student = new StudentContext(enrollmentNumber);
        student.setState(new SuspendedState());
        student.applyState();
        JOptionPane.showMessageDialog(this, "Student with enrollment number " + enrollmentNumber + " has been suspended.", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void viewPayments() {
        JFrame paymentFrame = new JFrame("Student Payments");
        paymentFrame.setSize(800, 400);
        paymentFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        String[] columnNames = {"Username", "Enrollment Number", "Email", "Year", "Payment"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        paymentFrame.add(scrollPane);

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT username, enrollmentNumber, email, year, payment FROM students";
            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {

                while (rs.next()) {
                    String username = rs.getString("username");
                    String enrollmentNumber = rs.getString("enrollmentNumber");
                    String email = rs.getString("email");
                    String year = rs.getString("year");
                    String payment = rs.getString("payment");

                    model.addRow(new Object[]{username, enrollmentNumber, email, year, payment});
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        paymentFrame.setVisible(true);
    }

    private void viewRoomAllocations() {
        JFrame frame = new JFrame("Room Allocations");
        frame.setSize(800, 400);
        frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    
        String[] columnNames = {"Student ID", "Username", "Gender", "Hostel Name", "Year", "Room ID", "Room Number", "State"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);
    
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane);
    
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT s.enrollmentNumber, s.username, s.gender, h.hostel_name, s.year, r.room_id, r.room_number, s.state " +
                           "FROM students s " +
                           "JOIN rooms r ON s.room_id = r.room_id " +
                           "JOIN hostels h ON r.hostel_id = h.hostel_id";
            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {
    
                while (rs.next()) {
                    int id = rs.getInt("enrollmentNumber");
                    String username = rs.getString("username");
                    String gender = rs.getString("gender");
                    String hostelName = rs.getString("hostel_name");
                    String year = rs.getString("year");
                    int roomId = rs.getInt("room_id");
                    int roomNumber = rs.getInt("room_number");
                    String state = rs.getString("state");
    
                    model.addRow(new Object[]{id, username, gender, hostelName, year, roomId, roomNumber, state});
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    
        frame.setVisible(true);
    }

    private void viewStructure() {
        List<HostelComponent> hostels = new ArrayList<>();
    
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String hostelQuery = "SELECT hostel_id, hostel_name FROM hostels";
            try (PreparedStatement hostelStmt = conn.prepareStatement(hostelQuery);
                 ResultSet hostelRs = hostelStmt.executeQuery()) {
    
                while (hostelRs.next()) {
                    int hostelId = hostelRs.getInt("hostel_id");
                    String hostelName = hostelRs.getString("hostel_name");
    
                    List<HostelComponent> rooms = new ArrayList<>();
                    String roomQuery = "SELECT room_id, room_number, capacity, state FROM rooms WHERE hostel_id = ?";
                    try (PreparedStatement roomStmt = conn.prepareStatement(roomQuery)) {
                        roomStmt.setInt(1, hostelId);
                        try (ResultSet roomRs = roomStmt.executeQuery()) {
                            while (roomRs.next()) {
                                int roomId = roomRs.getInt("room_id");
                                String roomNumber = roomRs.getString("room_number");
                                int capacity = roomRs.getInt("capacity");
                                String state = roomRs.getString("state");
    
                                Room room = new Room(roomId, roomNumber, capacity);
                                if ("occupied".equals(state)) {
                                    room.setState(new OccupiedState());
                                } else {
                                    room.setState(new VacantState());
                                }
                                rooms.add(room);
                            }
                        }
                    }
    
                    hostels.add(new Hostel(hostelId, hostelName, rooms));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 16));
        StringBuilder builder = new StringBuilder();
        for (HostelComponent hostel : hostels) {
            hostel.display(builder, "");
        }
        textArea.setText(builder.toString());
    
        JFrame frame = new JFrame("Hostel Structure");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        frame.add(new JScrollPane(textArea));
        frame.setVisible(true);
    }
    
        public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminHomePage("example@example.com").setVisible(true));
    }
}
