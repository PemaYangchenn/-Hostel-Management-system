import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.Base64;

public class AuthenticationManager {
    private static AuthenticationManager instance;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hostelmanagement";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private AuthenticationManager() {
        // Private constructor to prevent instantiation
    }

    public static AuthenticationManager getInstance() {
        if (instance == null) {
            instance = new AuthenticationManager();
        }
        return instance;
    }

    public String authenticate(String email, String password) {
        String hashedPassword = hashPassword(password);
        if (hashedPassword == null) {
            return "Error hashing password";
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String studentQuery = "SELECT * FROM students WHERE email=? AND hashedpassword=?";
            String adminQuery = "SELECT * FROM admin WHERE email=? AND hashedpassword=?";
            try (PreparedStatement studentPstmt = conn.prepareStatement(studentQuery);
                 PreparedStatement adminPstmt = conn.prepareStatement(adminQuery)) {

                studentPstmt.setString(1, email);
                studentPstmt.setString(2, hashedPassword);

                adminPstmt.setString(1, email);
                adminPstmt.setString(2, hashedPassword);

                try (ResultSet studentRs = studentPstmt.executeQuery();
                     ResultSet adminRs = adminPstmt.executeQuery()) {

                    if (studentRs.next()) {
                        return "Student";
                    } else if (adminRs.next()) {
                        return "Admin";
                    } else {
                        return "Invalid email or password";
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return "Error: " + ex.getMessage();
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
