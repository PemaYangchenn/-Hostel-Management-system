import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import HostelManagement.*;

public class SuspendedState implements StudentState {
    @Override
    public void handleState(StudentContext context) {
        System.out.println("Student is currently suspended.");
        updateDatabaseState(context.getEnrollmentNumber(), "suspended");
    }

    private void updateDatabaseState(String enrollmentNumber, String newState) {
        String DB_URL = "jdbc:mysql://localhost:3306/hostelmanagement";
        String DB_USER = "root";
        String DB_PASSWORD = "";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "UPDATE students SET state = ? WHERE enrollmentNumber = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, newState);
                pstmt.setString(2, enrollmentNumber);
                pstmt.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}