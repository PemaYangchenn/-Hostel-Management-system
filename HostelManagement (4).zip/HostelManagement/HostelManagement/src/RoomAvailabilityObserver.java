public interface RoomAvailabilityObserver {
    void update(boolean isRoomAvailable);
}
