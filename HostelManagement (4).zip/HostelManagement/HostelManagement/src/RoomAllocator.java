import HostelManagement.*;
public class RoomAllocator {
    private RoomAllocationStrategy strategy;

    public void setStrategy(RoomAllocationStrategy strategy) {
        this.strategy = strategy;
    }

    public void allocate() {
        if (strategy != null) {
            strategy.allocateRooms();
        } else {
            throw new IllegalStateException("Strategy not set.");
        }
    }
}
