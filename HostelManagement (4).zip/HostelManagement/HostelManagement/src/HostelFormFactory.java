import javax.swing.JFrame;
import HostelManagement.*;

public class HostelFormFactory implements FormFactory {
    @Override
    public JFrame createForm() {
        return new AddHostelForm();
    }
}
