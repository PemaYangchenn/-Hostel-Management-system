import HostelManagement.*;

public class PaymentProxy implements Payment {
    private RealPayment realPayment;

    @Override
    public void makePayment(String studentEmail) {
        if (realPayment == null) {
            realPayment = new RealPayment();
        }
        realPayment.makePayment(studentEmail);
    }
}
