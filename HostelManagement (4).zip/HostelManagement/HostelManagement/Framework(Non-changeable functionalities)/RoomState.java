public interface RoomState {
    void handle(Room room);
    String getState();
}