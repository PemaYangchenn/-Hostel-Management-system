public interface LoginObserver {
    void onLoginSuccess(String userType);
    void onLoginFailure();
}