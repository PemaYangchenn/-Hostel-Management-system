public interface RoomAllocationStrategy {
    void allocateRooms();
}