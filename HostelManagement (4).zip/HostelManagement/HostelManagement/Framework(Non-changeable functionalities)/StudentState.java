public interface StudentState {
    void handleState(StudentContext context);
}