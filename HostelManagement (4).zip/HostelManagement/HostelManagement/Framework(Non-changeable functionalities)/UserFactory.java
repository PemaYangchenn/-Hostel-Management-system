public abstract class UserFactory {
    public abstract User createUser(String username, String enrollmentNumber, String email, String hashedPassword, String gender, int year);
}