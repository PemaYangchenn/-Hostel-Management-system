public interface HostelComponent {
    void display(StringBuilder builder, String indent);
}