public interface Mediator {
    void sendFeedback(String email, String feedback);
}
