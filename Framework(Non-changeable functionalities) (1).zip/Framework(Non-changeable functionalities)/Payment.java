public interface Payment {
    void makePayment(String studentEmail);
}
