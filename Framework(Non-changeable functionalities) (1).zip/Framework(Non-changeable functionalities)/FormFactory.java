import javax.swing.JFrame;

public interface FormFactory {
    JFrame createForm();
}
